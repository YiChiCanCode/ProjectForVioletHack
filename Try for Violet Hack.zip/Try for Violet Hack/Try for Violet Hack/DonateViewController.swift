//
//  DonateViewController.swift
//  Try for Violet Hack
//
//  Created by 黃翊旗 on 2021/1/31.
//

import UIKit

class DonateViewController: UIViewController, UIPickerViewDelegate,  UIPickerViewDataSource {
    
    @IBOutlet weak var foodField: UITextField!
    @IBOutlet weak var numField: UITextField!
    @IBOutlet weak var dayField: UITextField!
    
    let food = ["milk", "bread", "vegetables", "eggs", "chips", "fruit", "cereal", "cheese", "meat", "soda", "coffee"]
    let number = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10" ]
    let day = ["1", "2", "3", "4", "5"]
    
    var foodPickerView = UIPickerView()
    var numberPickerView = UIPickerView()
    var dayPickerView = UIPickerView()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
    if segue.identifier == "store"{
        let destinationController  = segue.destination as! ShelfViewController
        destinationController.foodLabelText = foodField.text!
        destinationController.numberLabelText = numField.text!
        destinationController.dayLabelText = dayField.text!
    }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        foodPickerView.delegate = self
        foodPickerView.dataSource = self
        numberPickerView.delegate = self
        numberPickerView.dataSource = self
        dayPickerView.delegate = self
        dayPickerView.dataSource = self
        
        foodField.inputView = foodPickerView
        foodField.placeholder = "select food"
        numField.inputView = numberPickerView
        numField.placeholder = "select quantity"
        dayField.inputView = dayPickerView
        dayField.placeholder = "select quantity"
        
        foodPickerView.tag = 1
        numberPickerView.tag = 2
        dayPickerView.tag = 3
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        switch pickerView.tag {
        case 1:
            return food.count
        case 2:
            return number.count
        case 3:
            return day.count
        default:
            return 0
        }
    }
 
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag {
        case 1:
            return food[row]
        case 2:
            return number[row]
        case 3:
            return day[row]
        default:
            return ""
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag {
        case 1:
            foodField.text = food[row]
            foodField.resignFirstResponder()
        case 2:
            numField.text = number[row]
            numField.resignFirstResponder()
        case 3:
            dayField.text = day[row]
            dayField.resignFirstResponder()
        default:
            break
        }
        

      
    }
    
    

/* @IBAction func store(_ sender: Any) {
    class info {
        var food: String
        var number: String
        var day: String
        
        init(food: String, number: String, day:String) {
            self.food = food
            self.number = number
            self.day = day
        }
        
    }
    
    
} */


}
