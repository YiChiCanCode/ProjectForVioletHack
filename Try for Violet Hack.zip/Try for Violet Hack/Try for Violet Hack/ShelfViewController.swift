//
//  ShelfViewController.swift
//  Try for Violet Hack
//
//  Created by 黃翊旗 on 2021/1/31.
//

import UIKit

class ShelfViewController: UIViewController {

    @IBOutlet weak var foodLable: UILabel!
    @IBOutlet weak var numberLabel: UILabel!
     @IBOutlet weak var dayLabel: UILabel!
    
    var foodLabelText = ""
    var numberLabelText = ""
    var dayLabelText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        foodLable.text = foodLabelText
        numberLabel.text = numberLabelText
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
