//
//  ViewController.swift
//  Try for Violet Hack
//
//  Created by 黃翊旗 on 2021/1/31.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
   //    picker.dataSource = self
     //   picker.delegate = self 
        // Do any additional setup after loading the view.
    }
    
        
    }





